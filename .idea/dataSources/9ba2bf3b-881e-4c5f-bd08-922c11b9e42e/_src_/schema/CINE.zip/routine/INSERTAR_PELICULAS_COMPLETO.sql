CREATE PROCEDURE INSERTAR_PELICULAS_completo AS 
    CURSOR c_pelis2 IS
    SELECT distinct titulo,paises 
    FROM peliculas_completo2
    order by titulo;
    
    r_pelis c_pelis2%ROWTYPE;
    v_peli VARCHAR2(40):='';
    v_paises VARCHAR2(100):='';
BEGIN
  FOR r_pelis2 IN c_pelis2 LOOP
     if(v_peli=r_pelis2.titulo) then
        v_paises := v_paises||', '||r_pelis2.paises;
     else    
        --hemos cambiado de película
        update peliculas_completo set paises=v_paises
        where titulo=v_peli;
        --nos ponemos al día
        v_peli:=r_pelis2.titulo;
        v_paises:=r_pelis2.paises;
     end if;
       
  END LOOP;
  commit;
END INSERTAR_PELICULAS_completo;
/
